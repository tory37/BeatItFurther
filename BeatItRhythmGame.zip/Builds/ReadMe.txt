Group:
Phillip Huval
Christopher Boudreaux
Tory Hebert
Andrew Wise

Notes:
Needs an Xbox 360 Controller.

Hold the stick the direction the note is moving, then press the button on it as it 
moves over the center.
