﻿using UnityEngine;
using System.Collections;

public interface UILayer
{
	void OnFocus();
}
